from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timedelta
from pymongo import MongoClient
import os
import bcrypt
import jwt
import uuid
import json
from pathlib import Path
import shutil

app = FastAPI()

# Get MongoDB URL from environment
mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017/')
client = MongoClient(mongo_url)
db = client.couples_chat

# Collections
users_collection = db.users
messages_collection = db.messages
memories_collection = db.memories
calendar_collection = db.calendar

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()
SECRET_KEY = "your-secret-key-for-couples-app"

# Create uploads directory
uploads_dir = Path("uploads")
uploads_dir.mkdir(exist_ok=True)

# Mount static files
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# WebSocket manager for real-time chat
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def send_personal_message(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            await connection.send_text(message)

manager = ConnectionManager()

# Pydantic models
class User(BaseModel):
    username: str
    password: str
    display_name: str
    profile_image: Optional[str] = None

class UserLogin(BaseModel):
    username: str
    password: str

class Message(BaseModel):
    content: str
    sender: str
    timestamp: Optional[datetime] = None

class Memory(BaseModel):
    title: str
    content: str
    image_url: Optional[str] = None
    date: datetime
    category: str

class CalendarEvent(BaseModel):
    title: str
    date: datetime
    description: Optional[str] = None
    is_special: bool = False

class UserProfile(BaseModel):
    display_name: str
    bio: Optional[str] = None
    favorite_memory: Optional[str] = None
    relationship_since: Optional[datetime] = None

# Helper functions
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_token(username: str) -> str:
    payload = {
        'username': username,
        'exp': datetime.utcnow() + timedelta(days=30)
    }
    return jwt.encode(payload, SECRET_KEY, algorithm='HS256')

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=['HS256'])
        return payload['username']
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Initialize couple accounts on startup
async def init_couple_accounts():
    # Check if accounts exist
    if users_collection.count_documents({}) == 0:
        # Create two default accounts
        couple_accounts = [
            {
                "id": str(uuid.uuid4()),
                "username": "lover1",
                "password": hash_password("password123"),
                "display_name": "My Love 💕",
                "profile_image": None,
                "bio": "Half of my heart ❤️",
                "relationship_since": datetime.now()
            },
            {
                "id": str(uuid.uuid4()),
                "username": "lover2", 
                "password": hash_password("password123"),
                "display_name": "My Darling 💖",
                "profile_image": None,
                "bio": "The other half of my heart ❤️",
                "relationship_since": datetime.now()
            }
        ]
        users_collection.insert_many(couple_accounts)
        print("Created couple accounts: lover1/password123 and lover2/password123")

# API Routes
@app.on_event("startup")
async def startup_event():
    await init_couple_accounts()

@app.get("/api/")
async def root():
    return {"message": "Couples Chat API - Where love connects 💕"}

@app.post("/api/auth/login")
async def login(user: UserLogin):
    db_user = users_collection.find_one({"username": user.username})
    if not db_user or not verify_password(user.password, db_user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token = create_token(user.username)
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "username": db_user["username"],
            "display_name": db_user["display_name"],
            "id": db_user["id"]
        }
    }

@app.get("/api/auth/me")
async def get_current_user(username: str = Depends(verify_token)):
    user = users_collection.find_one({"username": username})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return {
        "username": user["username"],
        "display_name": user["display_name"],
        "id": user["id"],
        "bio": user.get("bio", ""),
        "relationship_since": user.get("relationship_since")
    }

@app.get("/api/messages")
async def get_messages(username: str = Depends(verify_token)):
    messages = list(messages_collection.find().sort("timestamp", 1))
    for message in messages:
        message["_id"] = str(message["_id"])
    return messages

@app.post("/api/messages")
async def send_message(message: Message, username: str = Depends(verify_token)):
    user = users_collection.find_one({"username": username})
    message_data = {
        "id": str(uuid.uuid4()),
        "content": message.content,
        "sender": user["display_name"],
        "sender_username": username,
        "timestamp": datetime.now(),
        "is_heart": "❤️" in message.content or "💕" in message.content or "💖" in message.content
    }
    
    messages_collection.insert_one(message_data)
    
    # Broadcast to all connected clients
    await manager.broadcast(json.dumps({
        "type": "message",
        "data": {
            "id": message_data["id"],
            "content": message_data["content"],
            "sender": message_data["sender"],
            "timestamp": message_data["timestamp"].isoformat(),
            "is_heart": message_data["is_heart"]
        }
    }))
    
    return {"message": "Message sent successfully"}

@app.get("/api/memories")
async def get_memories(username: str = Depends(verify_token)):
    memories = list(memories_collection.find().sort("date", -1))
    for memory in memories:
        memory["_id"] = str(memory["_id"])
    return memories

@app.post("/api/memories")
async def create_memory(memory: Memory, username: str = Depends(verify_token)):
    user = users_collection.find_one({"username": username})
    memory_data = {
        "id": str(uuid.uuid4()),
        "title": memory.title,
        "content": memory.content,
        "image_url": memory.image_url,
        "date": memory.date,
        "category": memory.category,
        "created_by": user["display_name"],
        "created_at": datetime.now()
    }
    
    memories_collection.insert_one(memory_data)
    return {"message": "Memory created successfully"}

@app.get("/api/calendar")
async def get_calendar_events(username: str = Depends(verify_token)):
    events = list(calendar_collection.find().sort("date", 1))
    for event in events:
        event["_id"] = str(event["_id"])
    return events

@app.post("/api/calendar")
async def create_calendar_event(event: CalendarEvent, username: str = Depends(verify_token)):
    user = users_collection.find_one({"username": username})
    event_data = {
        "id": str(uuid.uuid4()),
        "title": event.title,
        "date": event.date,
        "description": event.description,
        "is_special": event.is_special,
        "created_by": user["display_name"],
        "created_at": datetime.now()
    }
    
    calendar_collection.insert_one(event_data)
    return {"message": "Event created successfully"}

@app.post("/api/profile/update")
async def update_profile(profile: UserProfile, username: str = Depends(verify_token)):
    users_collection.update_one(
        {"username": username},
        {"$set": {
            "display_name": profile.display_name,
            "bio": profile.bio,
            "favorite_memory": profile.favorite_memory,
            "relationship_since": profile.relationship_since
        }}
    )
    return {"message": "Profile updated successfully"}

@app.websocket("/api/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await manager.broadcast(data)
    except WebSocketDisconnect:
        manager.disconnect(websocket)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)