import requests
import json
import sys
from datetime import datetime

class CouplesChatAPITester:
    def __init__(self, base_url):
        self.base_url = base_url
        self.token = None
        self.tests_run = 0
        self.tests_passed = 0
        self.user_data = None

    def run_test(self, name, method, endpoint, expected_status, data=None, auth=True):
        """Run a single API test"""
        url = f"{self.base_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}
        if auth and self.token:
            headers['Authorization'] = f'Bearer {self.token}'

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=headers)
            elif method == 'DELETE':
                response = requests.delete(url, headers=headers)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    return success, response.json()
                except:
                    return success, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    print(f"Response: {response.json()}")
                except:
                    print(f"Response: {response.text}")
                return False, {}

        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_root(self):
        """Test the root endpoint"""
        return self.run_test("Root API", "GET", "api", 200, auth=False)

    def test_login(self, username, password):
        """Test login and get token"""
        success, response = self.run_test(
            "Login",
            "POST",
            "api/auth/login",
            200,
            data={"username": username, "password": password},
            auth=False
        )
        if success and 'access_token' in response:
            self.token = response['access_token']
            self.user_data = response.get('user')
            return True
        return False

    def test_get_current_user(self):
        """Test getting current user info"""
        return self.run_test("Get Current User", "GET", "api/auth/me", 200)

    def test_get_messages(self):
        """Test getting messages"""
        return self.run_test("Get Messages", "GET", "api/messages", 200)

    def test_send_message(self, content):
        """Test sending a message"""
        return self.run_test(
            "Send Message",
            "POST",
            "api/messages",
            200,
            data={"content": content, "sender": self.user_data["display_name"] if self.user_data else "Test User"}
        )

    def test_get_memories(self):
        """Test getting memories"""
        return self.run_test("Get Memories", "GET", "api/memories", 200)

    def test_get_calendar(self):
        """Test getting calendar events"""
        return self.run_test("Get Calendar Events", "GET", "api/calendar", 200)

def main():
    # Get backend URL from frontend .env file
    import os
    with open('/app/frontend/.env', 'r') as f:
        for line in f:
            if line.startswith('REACT_APP_BACKEND_URL='):
                backend_url = line.strip().split('=')[1]
                break
    
    print(f"Using backend URL: {backend_url}")
    
    # Setup
    tester = CouplesChatAPITester(backend_url)
    
    # Test root endpoint
    tester.test_root()
    
    # Test login with both accounts
    print("\n===== Testing lover1 account =====")
    if not tester.test_login("lover1", "password123"):
        print("❌ Login failed for lover1, stopping tests")
        return 1
    
    # Test user info
    tester.test_get_current_user()
    
    # Test messages
    tester.test_get_messages()
    tester.test_send_message("Test message from lover1")
    tester.test_send_message("I love you ❤️")  # Test heart message
    
    # Test memories and calendar
    tester.test_get_memories()
    tester.test_get_calendar()
    
    # Test second account
    print("\n===== Testing lover2 account =====")
    if not tester.test_login("lover2", "password123"):
        print("❌ Login failed for lover2, stopping tests")
        return 1
    
    # Test user info for second account
    tester.test_get_current_user()
    
    # Test messages for second account
    tester.test_get_messages()
    tester.test_send_message("Test message from lover2")
    tester.test_send_message("Miss you 💕")  # Test heart message
    
    # Print results
    print(f"\n📊 Tests passed: {tester.tests_passed}/{tester.tests_run}")
    return 0 if tester.tests_passed == tester.tests_run else 1

if __name__ == "__main__":
    sys.exit(main())