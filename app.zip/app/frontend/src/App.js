import React, { useState, useEffect, useRef } from 'react';
import './App.css';

const App = () => {
  const [user, setUser] = useState(null);
  const [currentSection, setCurrentSection] = useState('chat');
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [memories, setMemories] = useState([]);
  const [calendarEvents, setCalendarEvents] = useState([]);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const ws = useRef(null);

  const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      fetchCurrentUser(token);
    }
  }, []);

  useEffect(() => {
    if (user) {
      fetchMessages();
      fetchMemories();
      fetchCalendarEvents();
      connectWebSocket();
    }
    return () => {
      if (ws.current) {
        ws.current.close();
      }
    };
  }, [user]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const connectWebSocket = () => {
    const wsUrl = API_URL.replace('http', 'ws') + '/api/ws';
    ws.current = new WebSocket(wsUrl);
    
    ws.current.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'message') {
        setMessages(prev => [...prev, data.data]);
      }
    };
    
    ws.current.onclose = () => {
      setTimeout(connectWebSocket, 3000);
    };
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const fetchCurrentUser = async (token) => {
    try {
      const response = await fetch(`${API_URL}/api/auth/me`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
      } else {
        localStorage.removeItem('token');
      }
    } catch (error) {
      console.error('Error fetching user:', error);
    }
  };

  const fetchMessages = async () => {
    try {
      const response = await fetch(`${API_URL}/api/messages`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
      }
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const fetchMemories = async () => {
    try {
      const response = await fetch(`${API_URL}/api/memories`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setMemories(data);
      }
    } catch (error) {
      console.error('Error fetching memories:', error);
    }
  };

  const fetchCalendarEvents = async () => {
    try {
      const response = await fetch(`${API_URL}/api/calendar`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setCalendarEvents(data);
      }
    } catch (error) {
      console.error('Error fetching calendar events:', error);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const response = await fetch(`${API_URL}/api/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(loginForm)
      });
      
      if (response.ok) {
        const data = await response.json();
        localStorage.setItem('token', data.access_token);
        setUser(data.user);
      } else {
        alert('Invalid credentials');
      }
    } catch (error) {
      console.error('Login error:', error);
      alert('Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    try {
      const response = await fetch(`${API_URL}/api/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          content: newMessage,
          sender: user.display_name
        })
      });

      if (response.ok) {
        setNewMessage('');
      }
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setUser(null);
    setMessages([]);
    setMemories([]);
    setCalendarEvents([]);
    if (ws.current) {
      ws.current.close();
    }
  };

  const addQuickMessage = (message) => {
    setNewMessage(message);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!user) {
    return (
      <div className="login-container">
        <div className="login-card">
          <div className="login-header">
            <h1>💕 Our Love Chat 💕</h1>
            <p>Where hearts connect</p>
          </div>
          <form onSubmit={handleLogin} className="login-form">
            <div className="form-group">
              <input
                type="text"
                placeholder="Username"
                value={loginForm.username}
                onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <input
                type="password"
                placeholder="Password"
                value={loginForm.password}
                onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                required
              />
            </div>
            <button type="submit" disabled={isLoading} className="login-btn">
              {isLoading ? 'Connecting...' : 'Connect Our Hearts 💖'}
            </button>
          </form>
          <div className="login-hint">
            <p>💡 Demo accounts:</p>
            <p>lover1 / password123</p>
            <p>lover2 / password123</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="app">
      <nav className="navbar">
        <div className="nav-brand">
          <h1>💕 Our Love Chat</h1>
        </div>
        <div className="nav-menu">
          <button 
            className={currentSection === 'chat' ? 'nav-item active' : 'nav-item'}
            onClick={() => setCurrentSection('chat')}
          >
            💬 Chat
          </button>
          <button 
            className={currentSection === 'memories' ? 'nav-item active' : 'nav-item'}
            onClick={() => setCurrentSection('memories')}
          >
            📸 Memories
          </button>
          <button 
            className={currentSection === 'calendar' ? 'nav-item active' : 'nav-item'}
            onClick={() => setCurrentSection('calendar')}
          >
            📅 Calendar
          </button>
          <button 
            className={currentSection === 'profile' ? 'nav-item active' : 'nav-item'}
            onClick={() => setCurrentSection('profile')}
          >
            👤 Profile
          </button>
        </div>
        <div className="nav-user">
          <span>{user.display_name}</span>
          <button onClick={handleLogout} className="logout-btn">Logout</button>
        </div>
      </nav>

      <main className="main-content">
        {currentSection === 'chat' && (
          <div className="chat-section">
            <div className="chat-header">
              <h2>💝 Our Private Chat</h2>
              <div className="quick-messages">
                <button onClick={() => addQuickMessage('I love you ❤️')} className="quick-msg">I love you ❤️</button>
                <button onClick={() => addQuickMessage('Miss you 💕')} className="quick-msg">Miss you 💕</button>
                <button onClick={() => addQuickMessage('Good morning sunshine 🌅')} className="quick-msg">Good morning 🌅</button>
              </div>
            </div>
            <div className="messages-container">
              {messages.map((message, index) => (
                <div key={index} className={`message ${message.sender_username === user.username ? 'message-sent' : 'message-received'}`}>
                  <div className="message-content">
                    <p>{message.content}</p>
                    <span className="message-time">{formatDate(message.timestamp)}</span>
                  </div>
                  {message.is_heart && <div className="heart-animation">💖</div>}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
            <form onSubmit={handleSendMessage} className="message-form">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type your love message..."
                className="message-input"
              />
              <button type="submit" className="send-btn">Send 💕</button>
            </form>
          </div>
        )}

        {currentSection === 'memories' && (
          <div className="memories-section">
            <div className="section-header">
              <h2>📸 Our Beautiful Memories</h2>
              <button className="add-btn">Add Memory +</button>
            </div>
            <div className="memories-grid">
              {memories.length === 0 ? (
                <div className="empty-state">
                  <h3>No memories yet 💭</h3>
                  <p>Start creating beautiful memories together!</p>
                </div>
              ) : (
                memories.map((memory, index) => (
                  <div key={index} className="memory-card">
                    <h3>{memory.title}</h3>
                    <p>{memory.content}</p>
                    <span className="memory-date">{formatDate(memory.date)}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {currentSection === 'calendar' && (
          <div className="calendar-section">
            <div className="section-header">
              <h2>📅 Our Special Dates</h2>
              <button className="add-btn">Add Event +</button>
            </div>
            <div className="calendar-grid">
              {calendarEvents.length === 0 ? (
                <div className="empty-state">
                  <h3>No events yet 📅</h3>
                  <p>Plan your special moments together!</p>
                </div>
              ) : (
                calendarEvents.map((event, index) => (
                  <div key={index} className="event-card">
                    <h3>{event.title}</h3>
                    <p>{event.description}</p>
                    <span className="event-date">{formatDate(event.date)}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {currentSection === 'profile' && (
          <div className="profile-section">
            <div className="section-header">
              <h2>👤 Our Love Story</h2>
            </div>
            <div className="profile-content">
              <div className="profile-card">
                <h3>{user.display_name}</h3>
                <p>{user.bio || 'No bio yet'}</p>
                <div className="profile-stats">
                  <div className="stat">
                    <span className="stat-number">{messages.length}</span>
                    <span className="stat-label">Messages</span>
                  </div>
                  <div className="stat">
                    <span className="stat-number">{memories.length}</span>
                    <span className="stat-label">Memories</span>
                  </div>
                  <div className="stat">
                    <span className="stat-number">{calendarEvents.length}</span>
                    <span className="stat-label">Events</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;